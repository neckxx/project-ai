'use client'
import { signIn } from 'next-auth/react'
export default function SignInPage(){ return (<div className='min-h-screen flex items-center justify-center'><div className='glass p-8 rounded-2xl max-w-md w-full text-center'><h2 className='text-2xl font-semibold mb-4'>Sign in to TerraAI</h2><button onClick={()=>signIn('google')} className='w-full py-2 rounded-md bg-gradient-to-r from-[#8b5cf6] to-[#7c3aed] text-white mb-3'>Continue with Google</button><a href='/auth/phone' className='text-sm underline'>Sign in with phone (OTP)</a></div></div>) }
