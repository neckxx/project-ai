import './globals.css'
import SessionProviderWrapper from '@/components/providers/SessionProviderWrapper'
import NavBar from '@/components/NavBar'
import { Suspense } from 'react'

export const metadata = {
  title: 'TerraAI',
  description: 'TerraAI - Your smart AI companion',
}

// Komponen shimmer loading
function ShimmerLoader() {
  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <div className="w-20 h-20 rounded-full bg-gradient-to-r from-violet-400 to-indigo-500 animate-pulse mb-4" />
      <p className="text-gray-400 animate-pulse">Loading...</p>
    </div>
  )
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="overflow-hidden"> {/* Hilangkan scrollbar */}
      <body className="bg-[#0f0f10] text-white">
        <SessionProviderWrapper>
          <div className="max-w-6xl mx-auto px-6">
            <NavBar />
            <main className="pt-6">
              {/* Suspense + shimmer loader */}
              <Suspense fallback={<ShimmerLoader />}>
                {children}
              </Suspense>
            </main>
          </div>
        </SessionProviderWrapper>
      </body>
    </html>
  )
}
